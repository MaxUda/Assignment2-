package magicrpg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class StartGame extends JPanel {
    private Image backgroundImage;

    StartGame() {
        // Load the background image
        backgroundImage = new ImageIcon("gameBG.png").getImage();

        setLayout(new BorderLayout()); // Use BorderLayout

        // Create a new panel
        JPanel panel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel1.setLayout(null); // Use null layout to freely position the label
        panel1.setOpaque(false);

        // Character
        ImageIcon chara = new ImageIcon("character.png"); // Load the image
        Image image = chara.getImage(); // transform it
        Image newimg = image.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH); // resize
        chara = new ImageIcon(newimg);

        // Create a Character object and add it to the panel
        Character character = new Character(chara, 0, 0, 5, 5);
        panel1.add(character); // Add the character to the panel

        // Add panel1 to the StartGame panel
        add(panel1, BorderLayout.CENTER);

        // Load new enemy images
        ImageIcon enemyWhite = new ImageIcon("enemywhite.png");
        ImageIcon enemyGrey = new ImageIcon("enemygrey.png");

        Image imageWhite = enemyWhite.getImage();
        Image newImgWhite = imageWhite.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
        enemyWhite = new ImageIcon(newImgWhite);

        Image imageGrey = enemyGrey.getImage();
        Image newImgGrey = imageGrey.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
        enemyGrey = new ImageIcon(newImgGrey);

        // Create Enemy objects with the new images and add them to the panel
        Enemy enemy1 = new Enemy(enemyWhite, 100, 100, 5, 5);
        Enemy enemy2 = new Enemy(enemyGrey, 200, 200, 5, 5);
        panel1.add(enemy1);
        panel1.add(enemy2);

        // Create a Timer to update the position of the enemies every 100 milliseconds
        Timer enemyTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enemy1.position(panel1.getWidth(), panel1.getHeight());
                enemy2.position(panel1.getWidth(), panel1.getHeight());
                enemy1.moveRandomly();
                enemy2.moveRandomly();
            }
        });
        enemyTimer.start(); // Start the Timer

        // Create a Timer to update the position of the character every 100 milliseconds
        Timer timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (character.direction) {
                    case "up":
                        character.moveUp();
                        break;
                    case "down":
                        character.moveDown();
                        break;
                    case "left":
                        character.moveLeft();
                        break;
                    case "right":
                        character.moveRight();
                        break;
                }
            }
        });
        timer.start(); // Start the Timer

        // Add key bindings for character movement
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("UP"), "moveUp");
        getActionMap().put("moveUp", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                character.moveUp();
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("DOWN"), "moveDown");
        getActionMap().put("moveDown", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                character.moveDown();
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("LEFT"), "moveLeft");
        getActionMap().put("moveLeft", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                character.moveLeft();
            }
        });

        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("RIGHT"), "moveRight");
        getActionMap().put("moveRight", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                character.moveRight();
            }
        });
    }
}
